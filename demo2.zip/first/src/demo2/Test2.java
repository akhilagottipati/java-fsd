package demo2;

import demo.Calculator;

public class Test2 {
	public static void main(String[] args) {
		Calculator calculator = new Calculator();
		calculator.add(30,20);
	}
	

}
