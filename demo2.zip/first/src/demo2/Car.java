package demo2;

public class Car {
	private String color;
	private String engineType;
	
	public Car(String colorOfCar, String typeOfEngine) {
		color = colorOfCar;
		engineType = typeOfEngine;
		}
	public void printCarPropertirs() {
		System.out.println("Color of Car = " + color);
		System.out.println("Type of Engine = " + engineType);
	}
	public static void main(String[] args) {
		Car mercedes = new Car("siver","petrol");
		
		Car audi = new Car("black","diesel");
		
		audi.printCarPropertirs();
		mercedes.printCarPropertirs();
	}

}
